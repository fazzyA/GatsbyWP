=== WP GraphiQL ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: http://example.com/
Tags: comments, spam
Requires at least: 4.4
Tested up to: 4.7.5
Stable tag: 0.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Brings the GraphiQL IDE to the WP-Admin

== Description ==

Brings the GraphiQL IDE to the WP-Admin, with Authentication built-in.
